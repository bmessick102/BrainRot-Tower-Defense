// AUTO-GENERATED from Game_Balance_Sheet.xlsx. Edit the spreadsheet, then re-export.
// Units: distances in tiles, times in seconds, money in gold.
// levels[i] = level i+1. Building cost at level 1 = shop price; later levels = upgrade price.
// waves[i] = scripted wave i+1; endless waves (5+) are computed from waves[3] in logic/waves.js.
// Map shape, image origin, town hall position, and spawn points live in src/mapTiles.js.
export const CONFIG = {
  grid: { tileWidth: 64, tileHeight: 32, townHallSize: 4, buildingSize: 3 },
  startingGold: 150,
  rules: {
    sellRefund: 0.5,
    repairCostOfLevel1: 0.25,
    storageDrainOnDestroy: 0.5,
    waveCountdown: 20,
    spawnInterval: 0.8,
    endlessCountGrowth: 1.15,
    endlessHpGrowth: 1.1,
    maxTownHallLevel: 5,
    mineCoinIconThreshold: 0.1
  },
  projectiles: {
    cannon: { speed: 12 },
    archer: { speed: 16 },
    wizard: { speed: 10 },
    mortar: { flightTime: 1.2 },
    slinger: { speed: 10 },
    bomber: { dropTime: 0.4 }
  },
  camera: { minZoom: 0.5, maxZoom: 2.0, dragThresholdPx: 6 },
  townHall: {
    name: "Town Hall",
    levels: [
      { upgradeCost: 0, hp: 1200, capacity: 500 },
      { upgradeCost: 300, hp: 1500, capacity: 750 },
      { upgradeCost: 1000, hp: 1875, capacity: 1000 },
      { upgradeCost: 2500, hp: 2344, capacity: 1500 },
      { upgradeCost: 5000, hp: 2930, capacity: 2000 }
    ]
  },
  mine: {
    name: "Bitcoin Mine",
    unlockTownHall: 1,
    levels: [
      { cost: 150, hp: 300, production: 2, stockCap: 120 },
      { cost: 300, hp: 375, production: 4, stockCap: 300 },
      { cost: 600, hp: 469, production: 6, stockCap: 540 },
      { cost: 1200, hp: 586, production: 9, stockCap: 900 },
      { cost: 2400, hp: 732, production: 12, stockCap: 1440 }
    ]
  },
  storage: {
    name: "Bitcoin Storage",
    unlockTownHall: 1,
    levels: [
      { cost: 100, hp: 500, capacity: 1000 },
      { cost: 200, hp: 625, capacity: 2000 },
      { cost: 400, hp: 781, capacity: 3500 },
      { cost: 800, hp: 977, capacity: 5500 },
      { cost: 1600, hp: 1221, capacity: 8000 }
    ]
  },
  defenses: {
    cannon: {
      name: "Cannon",
      hitsGround: true,
      hitsAir: false,
      fireInterval: 1.5,
      range: 4.5,
      minRange: 0,
      splashRadius: 0,
      unlockTownHall: 1,
      levels: [
        { cost: 150, hp: 400, damage: 40 },
        { cost: 300, hp: 500, damage: 50 },
        { cost: 600, hp: 625, damage: 63 },
        { cost: 1200, hp: 781, damage: 78 },
        { cost: 2400, hp: 977, damage: 98 }
      ]
    },
    archer: {
      name: "Archer Tower",
      hitsGround: true,
      hitsAir: true,
      fireInterval: 0.5,
      range: 7,
      minRange: 0,
      splashRadius: 0,
      unlockTownHall: 2,
      levels: [
        { cost: 250, hp: 350, damage: 12 },
        { cost: 500, hp: 438, damage: 15 },
        { cost: 1000, hp: 547, damage: 19 },
        { cost: 2000, hp: 684, damage: 23 },
        { cost: 4000, hp: 854, damage: 29 }
      ]
    },
    mortar: {
      name: "Mortar",
      hitsGround: true,
      hitsAir: false,
      fireInterval: 4,
      range: 10,
      minRange: 3,
      splashRadius: 1.5,
      unlockTownHall: 2,
      levels: [
        { cost: 400, hp: 450, damage: 50 },
        { cost: 800, hp: 563, damage: 63 },
        { cost: 1600, hp: 703, damage: 78 },
        { cost: 3200, hp: 879, damage: 98 },
        { cost: 6400, hp: 1099, damage: 122 }
      ]
    },
    wizard: {
      name: "Wizard Tower",
      hitsGround: true,
      hitsAir: true,
      fireInterval: 1,
      range: 4.5,
      minRange: 0,
      splashRadius: 1,
      unlockTownHall: 3,
      levels: [
        { cost: 600, hp: 400, damage: 22 },
        { cost: 1200, hp: 500, damage: 28 },
        { cost: 2400, hp: 625, damage: 34 },
        { cost: 4800, hp: 781, damage: 43 },
        { cost: 9600, hp: 977, damage: 54 }
      ]
    }
  },
  limits: {
    mine: [1, 2, 3, 3, 4],
    storage: [1, 1, 2, 2, 3],
    cannon: [1, 2, 2, 3, 3],
    archer: [0, 1, 2, 2, 3],
    mortar: [0, 1, 1, 2, 2],
    wizard: [0, 0, 1, 1, 2],
    townHall: [1, 1, 1, 1, 1]
  },
  enemies: {
    grunt: {
      name: "Grunt",
      type: "ground",
      hp: 75,
      speed: 0.9,
      damage: 8,
      attackInterval: 1,
      attackRange: 0.5,
      bounty: 3
    },
    slinger: {
      name: "Slinger",
      type: "ranged",
      hp: 150,
      speed: 1.1,
      damage: 15,
      attackInterval: 1.5,
      attackRange: 5,
      bounty: 10
    },
    bomber: {
      name: "Bomber",
      type: "air",
      hp: 220,
      speed: 1.6,
      damage: 40,
      attackInterval: 2,
      attackRange: 0,
      bounty: 15
    },
    tank: {
      name: "Tank",
      type: "ground",
      hp: 500,
      speed: 0.6,
      damage: 30,
      attackInterval: 2,
      attackRange: 0.5,
      bounty: 25
    }
  },
  waves: [
    { grunt: 8, slinger: 0, bomber: 0, tank: 0, spawnPaths: 1, hpMultiplier: 1 },
    { grunt: 20, slinger: 4, bomber: 0, tank: 0, spawnPaths: 1, hpMultiplier: 1 },
    { grunt: 25, slinger: 5, bomber: 4, tank: 0, spawnPaths: 2, hpMultiplier: 1.1 },
    { grunt: 35, slinger: 8, bomber: 7, tank: 3, spawnPaths: 2, hpMultiplier: 1.2 }
  ]
};

export default CONFIG;
